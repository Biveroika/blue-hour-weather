import { finite, numeric, dateLabel } from './weather.mjs';
export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
// Original weather glyphs on a 16 × 16 grid; no game artwork is bundled.
export function icon(type, className = '') {
  const cloud = '<path d="M3 7h2V5h5v1h2v2h2v4H2V8h1z"/>';
  const sun = '<path d="M6 4h4v1h1v1h1v4h-1v1h-1v1H6v-1H5v-1H4V6h1V5h1zM7 0h2v2H7zm0 14h2v2H7zM0 7h2v2H0zm14 0h2v2h-2zM2 2h2v2H2zm10 0h2v2h-2zM2 12h2v2H2zm10 0h2v2h-2z"/>';
  const moon = '<path d="M6 2h4v1H8v2H7v5h2v2h4v1h-2v1H6v-1H4v-2H3V6h1V4h2z"/>';
  let shape=cloud;
  if(type==='sun')shape=sun;
  if(type==='moon')shape=moon;
  if(type==='partly'||type==='mooncloud')shape='<g transform="translate(6 -1) scale(.65)">'+(type==='partly'?sun:moon)+'</g>'+cloud;
  if(type==='rain')shape=cloud+'<path d="M3 13h1v2H3zm5 0h1v2H8zm5 0h1v2h-1z"/>';
  if(type==='snow')shape=cloud+'<path d="M3 13h1v3H3zm-1 1h3v1H2zm10-1h1v3h-1zm-1 1h3v1h-3z"/>';
  if(type==='storm')shape=cloud+'<path d="M8 10h4l-3 3h2l-5 3 1-3H5z" fill="#e1c17a"/>';
  if(type==='fog')shape=cloud+'<path d="M1 13h14v1H1zm3 2h9v1H4z"/>';
  if(type==='unknown')shape='<path d="M5 3h6v1h1v4h-2v2H7V7h2V5H7v1H4V4h1zm2 10h3v3H7z"/>';
  return `<svg class="weather-icon ${escapeHtml(className)}" viewBox="-1 -1 18 18" aria-hidden="true" fill="currentColor" shape-rendering="crispEdges">${shape}</svg>`;
}
export function chart(series, { suffix = '', labels = [], second = null, id = 'chart-fill', minZero = false, accessible = '' } = {}) {
  const valid = [...series,...(second || [])].filter(finite);
  if (!valid.length) return '<div class="chart-foot">Для этого графика пока нет данных.</div>';
  const W=900, H=152, L=44, R=15, T=19, B=25;
  let min = Math.min(...valid), max = Math.max(...valid);
  const pad = Math.max((max-min)*.22, minZero ? 1 : .8);
  min = minZero ? Math.min(0,min) : min-pad; max+=pad;
  const x = i => L+i/Math.max(1,series.length-1)*(W-L-R);
  const y = v => T+(max-v)/Math.max(.1,max-min)*(H-T-B);
  const ticks=[0,.5,1].map(t => { const v = max-(max-min)*t, yy=y(v); return `<line class="grid" x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}"/><text x="${L-9}" y="${yy+4}" text-anchor="end">${escapeHtml(numeric(v,0))}</text>`; }).join('');
  function line(values,secondary=false) {
    let move=true; const coords=[];
    values.forEach((v,i)=>{ if (!finite(v)){move=true;return;} coords.push(`${move?'M':'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`);move=false; });
    const circles=values.map((v,i)=>finite(v)&&i%4===0?`<circle class="point${secondary?' secondary':''}" cx="${x(i)}" cy="${y(v)}" r="3.8"/>`:'').join('');
    return `<path class="curve${secondary?' secondary':''}" d="${coords.join(' ')}"/>${circles}`;
  }
  const labelCount=Math.min(7,series.length);
  const indices=[...new Set(Array.from({length:labelCount},(_,i)=>Math.round(i*(series.length-1)/Math.max(1,labelCount-1))))];
  const times=indices.map(i=>`<text x="${x(i)}" y="${H-4}" text-anchor="${i===0?'start':i===series.length-1?'end':'middle'}">${escapeHtml(labels[i] || '')}</text>`).join('');
  let area='';
  if (series.every(finite)) area=`<path class="area" style="fill:url(#${id})" d="M${x(0)},${H-B} ${series.map((v,i)=>`L${x(i)},${y(v)}`).join(' ')} L${x(series.length-1)},${H-B}Z"/>`;
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${escapeHtml(accessible || `График: ${numeric(Math.min(...valid),1)}–${numeric(Math.max(...valid),1)} ${suffix}`)}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="var(--accent)" stop-opacity=".2"/><stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>${ticks}${area}${line(series)}${second?line(second,true):''}${times}</svg>`;
}
export function metric(label,value,unit,detail,mark='↗') {
  return `<div class="metric-card"><div class="metric-label"><span class="metric-mark" aria-hidden="true">${mark}</span>${escapeHtml(label)}</div><div class="metric-value">${escapeHtml(value)}<small>${escapeHtml(unit)}</small></div><div class="metric-detail">${escapeHtml(detail)}</div></div>`;
}
export const detail = (label,value) => `<div class="detail-item"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></div>`;
export const timeOnly = value => typeof value==='string' && value.includes('T') ? value.split('T')[1].slice(0,5) : '—';
export const localDayLabel = (date, today) => date === today ? 'Сегодня' : dateLabel(date,{weekday:'short'});

// Monochrome phase disk follows the active accent, with the lit limb on its proper side.
export function moonIcon(phase) {
  const fraction = phase.index % 2 === 0 ? [0, .5, 1, .5][phase.index / 2] : phase.illumination / 100;
  const radius = Math.max(.01, Math.abs(1 - 2 * fraction) * 16);
  const light = fraction === 0 ? '' : fraction === 1 ? '<circle cx="20" cy="20" r="16" fill="currentColor"/>' : `<path d="M20 4 A16 16 0 0 1 20 36 A${radius} 16 0 0 ${fraction < .5 ? 0 : 1} 20 4" fill="currentColor" ${phase.index > 4 ? 'transform="translate(40 0) scale(-1 1)"' : ''}/>`;
  return `<svg class="moon-icon" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16" fill="currentColor" opacity=".16"/>${light}<circle cx="20" cy="20" r="16" fill="none" stroke="currentColor" stroke-width="1"/></svg>`;
}
