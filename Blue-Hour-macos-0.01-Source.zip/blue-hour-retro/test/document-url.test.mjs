import test from 'node:test';
import assert from 'node:assert/strict';
import { isAppDocument } from '../document-url.cjs';

const entry='file:///C:/Users/RUNNER%7E1/AppData/Local/Temp/Blue%20Hour/resources/app.asar/app/index.html';

test('Windows portable IPC accepts Chromium and Node encodings of the same file',()=>{
  assert.equal(isAppDocument(entry,entry),true);
  assert.equal(isAppDocument(entry.replace('%7E','~'),entry),true);
  assert.equal(isAppDocument(entry.replace('%7E','%7e'),entry),true);
});

test('Document validation still blocks unrelated local files and remote senders',()=>{
  for(const candidate of [undefined,'not a URL','https://example.com/app/index.html',
    entry.replace('index.html','other.html'),entry.replace('RUNNER%7E1','someone-else'),
    entry+'?query=1',entry+'#other',entry.replace('app/index.html','app%2Findex.html'),
    entry.replace('index.html','%invalid')]) {
    assert.equal(isAppDocument(candidate,entry),false,String(candidate));
  }
});
