// Tests the real built application on the ARM macOS runner.
module.exports = async function smokeCheck(window) {
  const { app, ipcMain } = require('electron');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const { pathToFileURL } = require('node:url');
  const output=path.resolve(process.env.BLUE_HOUR_SMOKE_DIR || 'smoke-output');
  const run=code=>window.webContents.executeJavaScript(code);
  await fs.mkdir(output,{recursive:true});
  const wait=condition=>run(`new Promise((resolve,reject)=>{const start=performance.now();const timer=setInterval(()=>{if(${condition}){clearInterval(timer);resolve(true);}else if(performance.now()-start>30000){clearInterval(timer);reject(Error('Timed out: '+${JSON.stringify(condition)}));}},100);})`);
  const controls=[];
  const record=(_event,action)=>controls.push(action);
  ipcMain.on('window-control',record);
  const capture=async name=>{await run('document.fonts.ready');await fs.writeFile(path.join(output,name),(await window.webContents.capturePage()).toPNG());};
  try {
    if(!app.isPackaged||app.getVersion()!=='0.0.1'||process.platform!=='darwin'||process.arch!=='arm64')throw Error('Expected packaged macOS ARM64 Revelations edition');
    await wait(`document.getElementById('app-version')?.textContent==='BLUE HOUR / macos 0.01' && !document.getElementById('refresh').disabled`);
    const quiet=await run(`({paused:document.getElementById('background-music').paused,audioCount:document.querySelectorAll('audio').length,retro:document.body.classList.contains('retro-edition'),classicControls:document.querySelectorAll('[data-window]').length,font:document.fonts.check('20px Tiny5'),version:document.getElementById('app-version').textContent})`);
    if(!quiet.paused||quiet.audioCount!==1||!quiet.retro||quiet.classicControls!==3)throw Error('Retro/silent startup mismatch: '+JSON.stringify(quiet));
    const { fixture }=await import(pathToFileURL(path.join(__dirname,'test/fixture.mjs')).href);
    await run(`{
      const NativeDate=Date;window.__smokeClock='2026-09-23T12:00:00Z';
      window.Date=class extends NativeDate{constructor(...args){super(...(args.length?args:[window.__smokeClock]));}static now(){return new NativeDate(window.__smokeClock).getTime();}};
      window.fetch=async()=>({ok:true,json:async()=>(${JSON.stringify(fixture())})});
      document.getElementById('refresh').click();
    }`);
    await wait(`!!document.querySelector('.temperature') && !document.getElementById('refresh').disabled`);
    await run(`document.body.classList.add('animations-off');`);
    await capture('revelations-current.png');
    const sidebar=await run(`({moon:document.getElementById('sidebar-phase').textContent,scroll:document.querySelector('.sidebar').scrollHeight,height:document.querySelector('.sidebar').clientHeight,overflow:document.querySelector('.main').scrollWidth>document.querySelector('.main').clientWidth+1})`);
    if(sidebar.overflow||sidebar.scroll>sidebar.height+1)throw Error('Unexpected layout overflow: '+JSON.stringify(sidebar));
    await run(`document.querySelector('.sidebar [data-view="week"]').click();document.querySelector('.day-card.full-moon').click();`);
    const cards=await run(`({count:document.querySelectorAll('.day-card').length,full:document.querySelectorAll('.day-card.full-moon').length,selected:document.querySelector('.day-card.selected').classList.contains('full-moon'),green:getComputedStyle(document.querySelector('.day-card.selected')).borderTopColor,paused:document.getElementById('background-music').paused})`);
    if(cards.count!==7||cards.full!==1||!cards.selected||cards.green!=='rgb(97, 186, 131)'||!cards.paused)throw Error('Forecast/silent navigation mismatch: '+JSON.stringify(cards));
    await capture('revelations-week.png');
    await run(`window.__smokeClock='2026-09-26T20:30:00Z';window.dispatchEvent(new Event('focus'));`);
    const night=await run(`({dark:document.body.classList.contains('dark-hour'),full:document.body.classList.contains('full-moon-night'),paused:document.getElementById('background-music').paused})`);
    if(!night.dark||!night.full||!night.paused)throw Error('Night theme mismatch');
    await capture('revelations-night.png');
    // Optional background music only; hovering and switching screens have no SFX.
    await run(`document.getElementById('music-toggle').click();`);
    const tracks=[];
    for(const [time,track]of [['2026-09-23T12:00:00Z','color'],['2026-09-23T20:30:00Z','voice'],['2026-09-26T20:30:00Z','shadow']]){
      await run(`window.__smokeClock=${JSON.stringify(time)};window.dispatchEvent(new Event('focus'));`);
      await wait(`document.getElementById('background-music').dataset.track===${JSON.stringify(track)}&&!document.getElementById('background-music').paused&&document.getElementById('background-music').currentTime>.1`);
      const result=await run(`(()=>{const a=document.getElementById('background-music');return {track:a.dataset.track,gain:a.volume,loop:a.loop,duration:a.duration};})()`);
      if(!result.loop||result.duration<60||Math.abs(result.gain-10**(-10/20))>1e-9)throw Error('Music mismatch');tracks.push(result);
    }
    await run(`document.getElementById('music-toggle').click();window.__smokeClock='2026-09-23T12:00:00Z';window.dispatchEvent(new Event('focus'));document.querySelector('.sidebar [data-view="pressure"]').click();`);
    const pressure=await run(`document.querySelector('.pressure-number').textContent`);
    if(!pressure.includes('747'))throw Error('Pressure screen failed');
    await capture('revelations-pressure.png');
    await run(`document.getElementById('settings-open').click();document.getElementById('app-version').click();document.getElementById('app-version').click();document.getElementById('app-version').click();`);
    const secret=await run(`({visible:!document.getElementById('settings-secret-message').hidden,text:document.getElementById('settings-secret-message').textContent,dialog:document.getElementById('settings-dialog').open})`);
    if(!secret.visible||!secret.dialog||secret.text!=='саня ван лав<3')throw Error('Settings secret failed');
    await capture('revelations-settings.png');
    await run(`document.querySelector('[data-close="settings-dialog"]').click();document.querySelector('[data-command="about"]').click();`);
    if(!await run(`document.getElementById('about-dialog').open`))throw Error('Classic menu failed');
    await capture('revelations-about.png');
    await run(`document.querySelector('[data-close="about-dialog"]').click();`);
    const waitWindow=condition=>new Promise((resolve,reject)=>{const start=Date.now();const timer=setInterval(()=>{if(condition()){clearInterval(timer);resolve();}else if(Date.now()-start>5000){clearInterval(timer);reject(Error('Native window control timed out'));}},50);});
    const initial=window.isMaximized();
    await run(`document.querySelector('[data-window="maximize"]').click();`);await waitWindow(()=>window.isMaximized()!==initial);
    await run(`document.querySelector('[data-window="maximize"]').click();`);await waitWindow(()=>window.isMaximized()===initial);
    await run(`document.querySelector('[data-window="minimize"]').click();`);await waitWindow(()=>window.isMinimized());window.restore();
    await waitWindow(()=>!window.isMinimized());
    await run(`document.querySelector('.sidebar [data-view="now"]').click();`);
    window.setSize(820,640);await capture('revelations-compact.png');
    const compact=await run(`({mainOverflow:document.querySelector('.main').scrollWidth>document.querySelector('.main').clientWidth+1,bodyOverflow:document.body.scrollWidth>innerWidth+1,sidebarScrollable:getComputedStyle(document.querySelector('.sidebar')).overflowY==='auto'})`);
    if(compact.mainOverflow||compact.bodyOverflow||!compact.sidebarScrollable)throw Error('Compact layout failed: '+JSON.stringify(compact));
    const result={edition:'macos 0.01',version:app.getVersion(),architecture:process.arch,packaged:app.isPackaged,platform:process.platform,quiet,sidebar,cards,night,tracks,pressure,secret,controls,compact};
    await fs.writeFile(path.join(output,'checks.json'),JSON.stringify(result,null,2));console.log('BLUE_HOUR_RETRO_OK '+JSON.stringify(result));app.exit(0);
  }catch(error){await fs.writeFile(path.join(output,'failure.txt'),error.stack);await capture('failure.png').catch(()=>{});console.error('BLUE_HOUR_RETRO_FAILED '+error.stack);app.exit(1);}
  finally{ipcMain.removeListener('window-control',record);}
};
