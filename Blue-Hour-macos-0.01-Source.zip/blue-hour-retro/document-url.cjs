const { fileURLToPath } = require('node:url');

// Chromium and Node can serialize the same local filename differently (e.g. ~ / %7E).
// Compare decoded file paths while rejecting remote URLs, fragments and queries.
function isAppDocument(candidate, entry) {
  if (typeof candidate !== 'string') return false;
  try {
    const actual = new URL(candidate);
    const expected = new URL(entry);
    if (actual.protocol !== 'file:' || actual.search || actual.hash) return false;
    return fileURLToPath(actual) === fileURLToPath(expected);
  } catch { return false; }
}

module.exports = { isAppDocument };
