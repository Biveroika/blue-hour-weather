export function fixture() {
  const hourly={time:[],temperature_2m:[],relative_humidity_2m:[],apparent_temperature:[],precipitation_probability:[],precipitation:[],weather_code:[],pressure_msl:[],surface_pressure:[],visibility:[],dew_point_2m:[],wind_speed_10m:[],wind_direction_10m:[],uv_index:[],is_day:[]};
  for(let i=0;i<168;i++) {
    const time=new Date(Date.UTC(2026,8,22,0)+i*3600000).toISOString().slice(0,16),hour=i%24;
    const row={time,temperature_2m:15+6*Math.sin((hour-6)*Math.PI/12),relative_humidity_2m:65,apparent_temperature:15,precipitation_probability:hour>16?60:10,precipitation:0,weather_code:hour>16?61:2,pressure_msl:1016+i*.08,surface_pressure:996+i*.08,visibility:20000,dew_point_2m:9,wind_speed_10m:2.4,wind_direction_10m:180,uv_index:2,is_day:hour>6&&hour<19?1:0};
    for(const field of Object.keys(hourly))hourly[field].push(row[field]);
  }
  const daily={time:[],weather_code:[],temperature_2m_max:[],temperature_2m_min:[],apparent_temperature_max:[],apparent_temperature_min:[],sunrise:[],sunset:[],daylight_duration:[],uv_index_max:[],precipitation_sum:[],precipitation_probability_max:[],wind_speed_10m_max:[],wind_gusts_10m_max:[],wind_direction_10m_dominant:[]};
  for(let i=0;i<7;i++) {
    const time=`2026-09-${22+i}`;
    const row={time,weather_code:[2,3,61,0,95,71,45][i],temperature_2m_max:21-i,temperature_2m_min:12-i,apparent_temperature_max:19-i,apparent_temperature_min:10-i,sunrise:time+'T06:17',sunset:time+'T18:39',daylight_duration:44520,uv_index_max:3.2,precipitation_sum:i===0?0:1.5,precipitation_probability_max:40,wind_speed_10m_max:4.5,wind_gusts_10m_max:8.1,wind_direction_10m_dominant:180};
    for(const field of Object.keys(daily))daily[field].push(row[field]);
  }
  return {latitude:55.75,longitude:37.62,elevation:144,timezone:'Europe/Moscow',utc_offset_seconds:10800,current:{time:'2026-09-22T12:15',temperature_2m:21.3,apparent_temperature:20,relative_humidity_2m:65,is_day:1,precipitation:0,weather_code:2,cloud_cover:40,pressure_msl:1016.9,surface_pressure:996.9,wind_speed_10m:2.4,wind_direction_10m:180,wind_gusts_10m:4.1},hourly,daily};
}
