const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktop', {
  control: action => { if (['minimize', 'maximize', 'close'].includes(action)) ipcRenderer.send('window-control', action); },
  openSource: () => ipcRenderer.send('open-source')
});
