export const ACCENT = '#126BFF';
export const DEFAULT_CITY = { id: 524901, name: 'Москва', admin1: 'Москва', country: 'Россия', latitude: 55.7522, longitude: 37.6156, timezone: 'Europe/Moscow' };
export const finite = value => typeof value === 'number' && Number.isFinite(value);
export const numeric = (value, digits = 0) => finite(value) ? value.toLocaleString('ru-RU', { maximumFractionDigits: digits }) : '—';
export const pressure = (value, unit) => finite(value) ? (unit === 'mmhg' ? value * 0.750061683 : value) : null;
export const pressureUnit = unit => unit === 'mmhg' ? 'мм рт. ст.' : 'гПа';
export const windDirection = degrees => finite(degrees) ? ['С', 'СВ', 'В', 'ЮВ', 'Ю', 'ЮЗ', 'З', 'СЗ'][Math.round(((degrees % 360) + 360) % 360 / 45) % 8] : '—';
export function condition(code, isDay = 1) {
  if (!finite(code)) return { name: 'Нет данных', icon: 'unknown', group: 'cloud' };
  if (code === 0) return { name: isDay ? 'Ясно' : 'Ясная ночь', icon: isDay ? 'sun' : 'moon', group: 'clear' };
  if (code <= 2) return { name: code === 1 ? 'Преимущественно ясно' : 'Переменная облачность', icon: isDay ? 'partly' : 'mooncloud', group: 'cloud' };
  if (code === 3) return { name: 'Пасмурно', icon: 'cloud', group: 'cloud' };
  if ([45,48].includes(code)) return { name: 'Туман', icon: 'fog', group: 'fog' };
  if ([51,53,55,56,57].includes(code)) return { name: [56,57].includes(code) ? 'Ледяная морось' : 'Морось', icon: 'rain', group: 'rain' };
  if ([61,63,65,66,67,80,81,82].includes(code)) return { name: [66,67].includes(code) ? 'Ледяной дождь' : [80,81,82].includes(code) ? 'Ливень' : code === 65 ? 'Сильный дождь' : 'Дождь', icon: 'rain', group: 'rain' };
  if ([71,73,75,77,85,86].includes(code)) return { name: code === 75 || code === 86 ? 'Сильный снег' : 'Снег', icon: 'snow', group: 'snow' };
  if ([95,96,99].includes(code)) return { name: code === 95 ? 'Гроза' : 'Гроза с градом', icon: 'storm', group: 'storm' };
  return { name: 'Нет данных', icon: 'unknown', group: 'cloud' };
}
export function forecastUrl(city) {
  if (!validCity(city)) throw new Error('Некорректные координаты города.');
  const params = new URLSearchParams({
    latitude: String(city.latitude), longitude: String(city.longitude), timezone: 'auto', forecast_days: '7', wind_speed_unit: 'ms', temperature_unit: 'celsius', precipitation_unit: 'mm',
    current: 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m',
    hourly: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,pressure_msl,surface_pressure,visibility,dew_point_2m,wind_speed_10m,wind_direction_10m,uv_index,is_day',
    daily: 'weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,daylight_duration,uv_index_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant'
  });
  return `https://api.open-meteo.com/v1/forecast?${params}`;
}
export function geocodingUrl(query) {
  return `https://geocoding-api.open-meteo.com/v1/search?${new URLSearchParams({ name: query.trim().slice(0,100), count:'7', language:'ru', format:'json' })}`;
}
export function validCity(city) {
  return !!city && typeof city.name === 'string' && city.name.length > 0 && finite(city.latitude) && finite(city.longitude) && Math.abs(city.latitude) <= 90 && Math.abs(city.longitude) <= 180;
}
export function validateForecast(data) {
  if (!data || data.error || typeof data.current?.time !== 'string' || !Array.isArray(data.daily?.time) || data.daily.time.length < 1 || !Array.isArray(data.hourly?.time) || !data.hourly.time.length) throw new Error('Сервис вернул неполную сводку. Попробуй обновить позже.');
  return data;
}
export function localNow(timezone, now = new Date()) {
  try {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('sv-SE', { timeZone: timezone, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23' }).formatToParts(now).map(x => [x.type,x.value]));
    return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
  } catch { return now.toISOString().slice(0,16); }
}
export function nextHours(data, count = 24) {
  const start = data.current.time.slice(0,13) + ':00';
  return data.hourly.time.map((time,index) => ({ time,index })).filter(x => x.time >= start).slice(0,count);
}
export function dayHours(data, day) {
  return data.hourly.time.map((time,index) => ({ time,index })).filter(x => x.time.startsWith(day));
}
export const mean = values => { const valid = values.filter(finite); return valid.length ? valid.reduce((a,b)=>a+b,0)/valid.length : null; };
export function pressureTrend(data, field = 'surface_pressure') {
  const hours = nextHours(data,4);
  const from = data.current[field];
  const to = data.hourly[field]?.[hours[3]?.index];
  return finite(from) && finite(to) ? to-from : null;
}
export function dateLabel(iso, options = { weekday:'short', day:'numeric', month:'short' }) {
  return new Intl.DateTimeFormat('ru-RU', { ...options, timeZone:'UTC' }).format(new Date(iso.slice(0,10)+'T12:00:00Z'));
}
export async function requestJson(url, signal) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (signal?.aborted) abort(); else signal?.addEventListener('abort', abort, { once: true });
  const timeout = setTimeout(abort, 18000);
  try {
    const response = await fetch(url, { signal: controller.signal, credentials:'omit', cache:'no-store' });
    if (!response.ok) throw new Error(response.status === 429 ? 'Слишком много запросов. Попробуй через минуту.' : `Сервис погоды недоступен (${response.status}).`);
    const data = await response.json();
    if (data.error) throw new Error('Сервис не смог обработать запрос. Попробуй позже.');
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error(signal?.aborted ? 'Запрос отменён.' : 'Сервис не ответил за 18 секунд. Проверь интернет и повтори.');
    if (error instanceof TypeError) throw new Error('Не удалось подключиться к Open-Meteo. Проверь интернет.');
    throw error;
  } finally { clearTimeout(timeout); signal?.removeEventListener('abort', abort); }
}
