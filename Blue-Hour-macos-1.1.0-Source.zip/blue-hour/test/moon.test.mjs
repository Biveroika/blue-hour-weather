import test from 'node:test';
import assert from 'node:assert/strict';
import { moonForDay, localNoon, nightState, previousDate } from '../app/moon.mjs';
import { localNow } from '../app/weather.mjs';

test('Full moon matches USNO 2026-09-26 16:49 UTC and is marked on exactly one local day', () => {
  // Reference: https://aa.usno.navy.mil/calculated/moon/phases?year=2026
  const moon = moonForDay('2026-09-26', 'UTC');
  assert.equal(moon.isFull, true);
  const minutes = Number(moon.eventTime.slice(0,2)) * 60 + Number(moon.eventTime.slice(3));
  assert.ok(Math.abs(minutes - (16*60+49)) <= 2);
  assert.equal(moonForDay('2026-09-25', 'UTC').isFull, false);
  assert.equal(moonForDay('2026-09-27', 'UTC').isFull, false);
  assert.equal(moonForDay('2026-09-26', 'Asia/Tokyo').isFull, false);
  assert.equal(moonForDay('2026-09-27', 'Asia/Tokyo').isFull, true);
  assert.equal(moonForDay('2026-09-26', 'Pacific/Honolulu').isFull, true);
});

test('All principal phases are distinct, with illuminated fraction in bounds', () => {
  assert.equal(moonForDay('2026-09-11').id, 'new');
  assert.equal(moonForDay('2026-09-18').id, 'first-quarter');
  assert.equal(moonForDay('2026-10-03').id, 'last-quarter');
  for (let day=1; day<=30; day++) {
    const moon=moonForDay(`2026-09-${String(day).padStart(2,'0')}`,'Europe/Moscow');
    assert.ok(moon.illumination>=0 && moon.illumination<=100);
    assert.ok(moon.name && moon.nextFullDate);
  }
});

test('Local noon resolves DST, fractional offsets and UTC+14 correctly', () => {
  for (const [date,timezone] of [['2026-03-08','America/New_York'],['2026-11-01','America/New_York'],['2026-09-27','Pacific/Auckland'],['2026-09-26','Asia/Kathmandu'],['2026-09-26','Pacific/Kiritimati']]) {
    assert.equal(localNow(timezone,localNoon(date,timezone)),date+'T12:00');
  }
  assert.equal(previousDate('2027-01-01'),'2026-12-31');
});

test('Night soundtrack switches exactly at 23:00 and 01:00 in the selected city', () => {
  const zone='Europe/Moscow';
  const at=(iso)=>nightState(zone,new Date(iso));
  assert.equal(at('2026-09-23T19:59:59Z').track,'color');
  assert.equal(at('2026-09-23T20:00:00Z').track,'voice');
  assert.equal(at('2026-09-23T21:00:00Z').track,'voice');
  assert.equal(at('2026-09-23T21:59:59Z').track,'voice');
  assert.equal(at('2026-09-23T22:00:00Z').track,'color');
  assert.equal(at('2026-09-26T20:00:00Z').track,'shadow');
  assert.equal(at('2026-09-26T21:59:59Z').track,'shadow');
  assert.equal(at('2026-09-26T22:00:00Z').track,'color');
  assert.equal(at('2026-09-27T20:00:00Z').track,'voice');
  assert.equal(at('2026-09-25T21:30:00Z').track,'voice');
  assert.equal(nightState('Asia/Tokyo',new Date('2026-09-27T14:30:00Z')).track,'shadow');
});
