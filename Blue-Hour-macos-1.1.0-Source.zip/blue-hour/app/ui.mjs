import { finite, numeric, dateLabel } from './weather.mjs';
export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const cloud = '<path d="M24 66h46a16 16 0 0 0 2-32 23 23 0 0 0-44-3 18 18 0 0 0-4 35Z"/>';
const rays = '<path d="M50 9V1m0 98v-8M9 50H1m98 0h-8M21 21l-6-6m70 70-6-6m0-58 6-6M15 85l6-6"/>';
export function icon(type, className = '') {
  let shape = cloud;
  if (type === 'sun') shape = `<circle cx="50" cy="50" r="25"/>${rays}`;
  if (type === 'moon') shape = '<path d="M65 10a40 40 0 1 0 25 63A37 37 0 0 1 65 10Z"/>';
  if (type === 'partly' || type === 'mooncloud') shape = (type === 'partly' ? '<circle cx="65" cy="28" r="17"/><path d="M65 3v-6m25 31h8M83 10l5-5M47 10l-5-5"/>' : '<path d="M74 5a25 25 0 0 0 20 40A24 24 0 0 1 74 5Z"/>') + '<g transform="translate(-6 17) scale(.9)">'+cloud+'</g>';
  if (type === 'rain') shape += '<path d="m30 78-5 12m25-12-5 12m25-12-5 12"/>';
  if (type === 'snow') shape += '<path d="M27 77v17m-7-13 14 9m0-9-14 9m48-13v17m-7-13 14 9m0-9-14 9"/>';
  if (type === 'storm') shape += '<path d="m52 66-15 19h13l-6 15 22-24H53l6-10" fill="currentColor" stroke="none"/>';
  if (type === 'fog') shape += '<path d="M15 78h70M25 89h50"/>';
  if (type === 'unknown') shape = '<circle cx="50" cy="50" r="32"/><path d="M40 38c0-15 25-15 22 0-1 7-12 8-12 18m0 12v1"/>';
  return `<svg class="weather-icon ${className}" viewBox="-5 -5 110 110" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round">${shape}</svg>`;
}
export function chart(series, { suffix = '', labels = [], second = null, id = 'chart-fill', minZero = false, accessible = '' } = {}) {
  const valid = [...series,...(second || [])].filter(finite);
  if (!valid.length) return '<div class="chart-foot">Для этого графика пока нет данных.</div>';
  const W=900, H=152, L=44, R=15, T=19, B=25;
  let min = Math.min(...valid), max = Math.max(...valid);
  const pad = Math.max((max-min)*.22, minZero ? 1 : .8);
  min = minZero ? Math.min(0,min) : min-pad; max+=pad;
  const x = i => L+i/Math.max(1,series.length-1)*(W-L-R);
  const y = v => T+(max-v)/Math.max(.1,max-min)*(H-T-B);
  const ticks=[0,.5,1].map(t => { const v = max-(max-min)*t, yy=y(v); return `<line class="grid" x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}"/><text x="${L-9}" y="${yy+4}" text-anchor="end">${escapeHtml(numeric(v,0))}</text>`; }).join('');
  function line(values,secondary=false) {
    let move=true; const coords=[];
    values.forEach((v,i)=>{ if (!finite(v)){move=true;return;} coords.push(`${move?'M':'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`);move=false; });
    const circles=values.map((v,i)=>finite(v)&&i%4===0?`<circle class="point${secondary?' secondary':''}" cx="${x(i)}" cy="${y(v)}" r="3.8"/>`:'').join('');
    return `<path class="curve${secondary?' secondary':''}" d="${coords.join(' ')}"/>${circles}`;
  }
  const labelCount=Math.min(7,series.length);
  const indices=[...new Set(Array.from({length:labelCount},(_,i)=>Math.round(i*(series.length-1)/Math.max(1,labelCount-1))))];
  const times=indices.map(i=>`<text x="${x(i)}" y="${H-4}" text-anchor="${i===0?'start':i===series.length-1?'end':'middle'}">${escapeHtml(labels[i] || '')}</text>`).join('');
  let area='';
  if (series.every(finite)) area=`<path class="area" style="fill:url(#${id})" d="M${x(0)},${H-B} ${series.map((v,i)=>`L${x(i)},${y(v)}`).join(' ')} L${x(series.length-1)},${H-B}Z"/>`;
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${escapeHtml(accessible || `График: ${numeric(Math.min(...valid),1)}–${numeric(Math.max(...valid),1)} ${suffix}`)}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="var(--accent)" stop-opacity=".2"/><stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>${ticks}${area}${line(series)}${second?line(second,true):''}${times}</svg>`;
}
export function metric(label,value,unit,detail,mark='↗') {
  return `<div class="metric-card"><div class="metric-label"><span class="metric-mark" aria-hidden="true">${mark}</span>${escapeHtml(label)}</div><div class="metric-value">${escapeHtml(value)}<small>${escapeHtml(unit)}</small></div><div class="metric-detail">${escapeHtml(detail)}</div></div>`;
}
export const detail = (label,value) => `<div class="detail-item"><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></div>`;
export const timeOnly = value => typeof value==='string' && value.includes('T') ? value.split('T')[1].slice(0,5) : '—';
export const localDayLabel = (date, today) => date === today ? 'Сегодня' : dateLabel(date,{weekday:'short'});

// Monochrome phase disk follows the active accent, with the lit limb on its proper side.
export function moonIcon(phase) {
  const fraction = phase.index % 2 === 0 ? [0, .5, 1, .5][phase.index / 2] : phase.illumination / 100;
  const radius = Math.max(.01, Math.abs(1 - 2 * fraction) * 16);
  const light = fraction === 0 ? '' : fraction === 1 ? '<circle cx="20" cy="20" r="16" fill="currentColor"/>' : `<path d="M20 4 A16 16 0 0 1 20 36 A${radius} 16 0 0 ${fraction < .5 ? 0 : 1} 20 4" fill="currentColor" ${phase.index > 4 ? 'transform="translate(40 0) scale(-1 1)"' : ''}/>`;
  return `<svg class="moon-icon" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="16" fill="currentColor" opacity=".16"/>${light}<circle cx="20" cy="20" r="16" fill="none" stroke="currentColor" stroke-width="1"/></svg>`;
}
