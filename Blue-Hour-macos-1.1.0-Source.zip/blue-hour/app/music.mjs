// A decibel level describes amplitude logarithmically, not a percentage slider.
export const MUSIC_GAIN = 10 ** (-10 / 20);
export const TRACKS = Object.freeze({
  color: { src: 'audio/color-your-night.mp3', title: 'COLOR YOUR NIGHT' },
  voice: { src: 'audio/the-voice-someone-calls.m4a', title: 'THE VOICE SOMEONE CALLS' },
  shadow: { src: 'audio/master-of-shadow.m4a', title: 'MASTER OF SHADOW' }
});

export function setupMusic({ audio, button, label, select, read, save, document, track = 'color' }) {
  let enabled = read('music', true) !== false;
  let pending = false;
  let failed = false;
  let generation = 0;
  let currentTrack = TRACKS[track] ? track : 'color';
  audio.setAttribute('src', TRACKS[currentTrack].src);
  audio.volume = MUSIC_GAIN;
  audio.loop = true;

  function sync() {
    const playing = enabled && !audio.paused && !failed;
    button.setAttribute('aria-pressed', String(playing));
    button.setAttribute('aria-label', enabled ? 'Выключить музыку' : 'Включить музыку');
    button.classList.toggle('playing', playing);
    label.textContent = failed ? 'Аудио недоступно' : !enabled ? 'Музыка выключена' : pending ? 'Нажми, чтобы включить' : TRACKS[currentTrack].title;
    button.title = TRACKS[currentTrack].title + ' · −10 дБ';
    audio.dataset.track = currentTrack;
    select.value = enabled ? 'on' : 'off';
  }
  async function play() {
    if (!enabled) return;
    const current = ++generation;
    failed = false;
    try {
      await audio.play();
      if (current !== generation) return;
      pending = false;
    } catch (error) {
      if (current !== generation) return;
      pending = error?.name === 'NotAllowedError';
      failed = !pending;
    }
    sync();
  }
  function setEnabled(value) {
    enabled = value;
    save('music', enabled);
    if (enabled) { void play(); }
    else { ++generation; audio.pause(); pending = false; failed = false; }
    sync();
  }
  function setTrack(value) {
    if (!TRACKS[value] || currentTrack === value) return;
    ++generation;
    currentTrack = value;
    audio.pause();
    audio.setAttribute('src', TRACKS[value].src);
    audio.load();
    failed = false;
    pending = false;
    sync();
    if (enabled) void play();
  }
  button.addEventListener('click', () => setEnabled(pending || failed ? true : !enabled));
  select.addEventListener('change', () => setEnabled(select.value === 'on'));
  audio.addEventListener('playing', sync);
  audio.addEventListener('pause', sync);
  audio.addEventListener('error', () => { failed = true; pending = false; sync(); });
  // Browsers may block autoplay; the packaged desktop app permits it.
  const retry = () => { if (enabled && pending) void play(); };
  document.addEventListener('pointerdown', retry);
  document.addEventListener('keydown', retry);
  sync();
  if (enabled) void play();
  return { setEnabled, setTrack };
}
