export function setupEasterEgg(button, message, { now = Date.now, schedule = setTimeout, cancel = clearTimeout } = {}) {
  let clicks = [];
  let hideTimer;
  button.addEventListener('click', () => {
    const time = now();
    clicks = clicks.filter(t => time - t <= 1500);
    clicks.push(time);
    if (clicks.length < 3) return;
    clicks = [];
    cancel(hideTimer);
    message.hidden = false;
    hideTimer = schedule(() => { message.hidden = true; }, 6000);
  });
}
