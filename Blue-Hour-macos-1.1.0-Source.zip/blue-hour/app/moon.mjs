import { MoonPhase, Illumination, SearchMoonQuarter, NextMoonQuarter, SearchMoonPhase } from './vendor/astronomy.mjs';
import { localNow } from './weather.mjs';

const DAY = 86400000;
const monthCache = new Map();
const dayCache = new Map();
const phases = [
  ['new', 'Новолуние'], ['waxing-crescent', 'Растущий серп'],
  ['first-quarter', 'Первая четверть'], ['waxing-gibbous', 'Растущая Луна'],
  ['full', 'Полнолуние'], ['waning-gibbous', 'Убывающая Луна'],
  ['last-quarter', 'Последняя четверть'], ['waning-crescent', 'Убывающий серп']
];

function cacheResult(cache, key, value, limit) {
  if (cache.size >= limit) cache.delete(cache.keys().next().value);
  cache.set(key, value);
  return value;
}

// Resolve local noon, including DST and half/quarter-hour timezone offsets.
export function localNoon(date, timezone) {
  const target = Date.parse(date + 'T12:00:00Z');
  let instant = target;
  for (let i = 0; i < 4; i++) {
    const wall = Date.parse(localNow(timezone, new Date(instant)) + ':00Z');
    const delta = target - wall;
    instant += delta;
    if (!delta) break;
  }
  return new Date(instant);
}

function monthEvents(date, timezone) {
  const key = timezone + '/' + date.slice(0, 7);
  if (monthCache.has(key)) return monthCache.get(key);
  const [year, month] = date.split('-').map(Number);
  const start = new Date(Date.UTC(year, month - 1, 1) - 2 * DAY);
  const end = Date.UTC(year, month, 1) + 2 * DAY;
  const events = new Map();
  let event = SearchMoonQuarter(start);
  while (event.time.date.getTime() < end) {
    events.set(localNow(timezone, event.time.date).slice(0, 10), event);
    event = NextMoonQuarter(event);
  }
  return cacheResult(monthCache, key, events, 8);
}

export function moonForDay(date, timezone = 'UTC') {
  const key = timezone + '/' + date;
  if (dayCache.has(key)) return dayCache.get(key);
  const noon = localNoon(date, timezone);
  const angle = MoonPhase(noon);
  const event = monthEvents(date, timezone).get(date);
  // An exact primary phase labels one local calendar day, never a multi-day threshold.
  const index = event ? event.quarter * 2 : angle < 90 ? 1 : angle < 180 ? 3 : angle < 270 ? 5 : 7;
  const [id, name] = phases[index];
  const nextFull = SearchMoonPhase(180, noon, 35)?.date;
  return cacheResult(dayCache, key, {
    id, name, index, angle, date, isFull: id === 'full',
    illumination: Math.round(Illumination('Moon', noon).phase_fraction * 100),
    eventTime: event ? localNow(timezone, event.time.date).slice(11, 16) : null,
    nextFullDate: nextFull ? localNow(timezone, nextFull).slice(0, 10) : null
  }, 128);
}

export function previousDate(date) {
  return new Date(Date.parse(date + 'T12:00:00Z') - DAY).toISOString().slice(0, 10);
}

export function nightState(timezone = 'UTC', now = new Date()) {
  const local = localNow(timezone, now);
  const hour = Number(local.slice(11, 13));
  const active = hour >= 23 || hour < 1;
  // 00:00–00:59 belongs to the evening that started the same two-hour night.
  const nightDate = hour < 1 ? previousDate(local.slice(0, 10)) : local.slice(0, 10);
  const fullMoon = active && moonForDay(nightDate, timezone).isFull;
  return { active, fullMoon, nightDate, track: active ? (fullMoon ? 'shadow' : 'voice') : 'color' };
}
