const { app, BrowserWindow, ipcMain, shell, session, Menu } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const entry = pathToFileURL(path.join(__dirname, 'app/index.html')).href;
const single = app.requestSingleInstanceLock();
if (!single) app.quit();
const isMac = process.platform === 'darwin';
const smokeTest = process.argv.includes('--smoke-test');
let window;
function createWindow() {
  window = new BrowserWindow({
    title: 'Blue Hour', width: 1370, height: 900, minWidth: 980, minHeight: 720,
    backgroundColor: '#08090d', frame: isMac, show: false,
    ...(isMac ? { titleBarStyle: 'hidden', trafficLightPosition: { x: 14, y: 10 } } : {}),
    icon: path.join(__dirname, isMac ? 'assets/icon-macos.png' : 'assets/icon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true, autoplayPolicy: 'no-user-gesture-required' }
  });
  window.once('ready-to-show', () => window.show());
  window.on('closed', () => { window = null; });
  if (smokeTest) window.webContents.once('did-finish-load', () => require('./smoke-check.cjs')(window));
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event, url) => { if (url !== entry) event.preventDefault(); });
  window.loadFile(path.join(__dirname, 'app/index.html'));
}
app.on('second-instance', () => { if (window) { if (window.isMinimized()) window.restore(); window.show(); window.focus(); } });
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
  session.defaultSession.setPermissionCheckHandler(() => false);
  ipcMain.on('window-control', (event, action) => {
    if (event.sender !== window?.webContents || event.senderFrame?.url !== entry) return;
    if (action === 'minimize') window.minimize();
    if (action === 'maximize') window.isMaximized() ? window.unmaximize() : window.maximize();
    if (action === 'close') window.close();
  });
  ipcMain.on('open-source', event => {
    if (event.sender === window?.webContents && event.senderFrame?.url === entry) shell.openExternal('https://open-meteo.com/');
  });
  if (isMac) Menu.setApplicationMenu(Menu.buildFromTemplate([
    { role: 'appMenu' },
    { role: 'editMenu' },
    { role: 'viewMenu' },
    { role: 'windowMenu' }
  ]));
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (!isMac) app.quit(); });
