import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { fixture } from './fixture.mjs';
const root=new URL('../',import.meta.url);
let script=['weather.mjs','ui.mjs','music.mjs','app.mjs'].map(name=>{let text=fs.readFileSync(new URL('app/'+name,root),'utf8').replace(/^import .*\n/gm,'').replace(/\bexport /g,'');return name==='app.mjs'?'const n=numeric,e=escapeHtml;\n'+text:text;}).join('\n');
const html=fs.readFileSync(new URL('app/index.html',root),'utf8');
const city={id:1,name:'Токио',latitude:35.68,longitude:139.69,country:'Япония',timezone:'Asia/Tokyo'};
const tick=()=>new Promise(resolve=>setTimeout(resolve,15));
function boot({fetch=async url=>({ok:true,json:async()=>String(url).includes('/search?')?{results:[city]}:fixture()}),saved={}}={}){
  const dom=new JSDOM(html,{url:'https://bluehour.test',runScripts:'outside-only',pretendToBeVisual:true});
  const {window:w}=dom;w.fetch=fetch;w.HTMLElement.prototype.scrollTo=function(){};
  w.HTMLMediaElement.prototype.play=async function(){Object.defineProperty(this,'paused',{value:false,configurable:true});this.dispatchEvent(new w.Event('playing'));};
  w.HTMLMediaElement.prototype.pause=function(){Object.defineProperty(this,'paused',{value:true,configurable:true});this.dispatchEvent(new w.Event('pause'));};
  w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');};
  for(const [key,val]of Object.entries(saved))w.localStorage.setItem('bluehour:'+key,JSON.stringify(val));
  w.eval(script);return {dom,w,doc:w.document,close:()=>w.close()};
}
test('Full application shows live data, all seven days and changes pressure units',async()=>{
  const app=boot();try{await tick();const {doc,w}=app;
    assert.match(doc.querySelector('.temperature').textContent,/21/);assert.equal(doc.querySelectorAll('.metric-card').length,8);
    doc.querySelector('[data-view="week"]').click();assert.equal(doc.querySelectorAll('.day-card').length,7);
    doc.querySelector('[data-day="6"]').click();assert.match(doc.querySelector('.day-detail h2').textContent,/28/);
    doc.querySelector('[data-view="pressure"]').click();assert.match(doc.querySelector('.pressure-number').textContent,/747/);
    const select=doc.getElementById('pressure-unit');select.value='hpa';select.dispatchEvent(new w.Event('change'));assert.match(doc.querySelector('.pressure-number').textContent,/996,9/);
    doc.querySelector('[data-pressure="pressure_msl"]').click();assert.match(doc.querySelector('.pressure-number').textContent,/1.?016,9/);
    assert.equal(doc.getElementById('content').getAttribute('aria-busy'),'false');
  }finally{app.close();}
});
test('City search and selection update the forecast, stored city and dialog',async()=>{
  const requested=[];const app=boot({fetch:async url=>{requested.push(String(url));return {ok:true,json:async()=>String(url).includes('/search?')?{results:[city]}:fixture()};}});
  try{await tick();const {doc,w}=app;doc.getElementById('city-open').click();doc.getElementById('city-search').value='Токио';doc.getElementById('city-form').dispatchEvent(new w.Event('submit',{cancelable:true}));await tick();doc.querySelector('[data-result="0"]').click();await tick();assert.equal(doc.getElementById('city-name').textContent,'Токио');assert.ok(requested.some(url=>url.includes('latitude=35.68')));assert.equal(doc.getElementById('city-dialog').open,false);assert.equal(JSON.parse(w.localStorage.getItem('bluehour:city')).name,'Токио');}finally{app.close();}
});
test('A failed request displays cached data with an explicit stale notice',async()=>{
  const cache={'55.752,37.616':{data:fixture(),fetchedAt:Date.now()-900000}};
  const app=boot({fetch:async()=>{throw new Error('Offline');},saved:{cache}});
  try{await tick();assert.match(app.doc.getElementById('data-status').textContent,/Сохранённая/);assert.match(app.doc.getElementById('notice').textContent,/сохранённая сводка/);assert.ok(app.doc.querySelector('.temperature'));}finally{app.close();}
});
test('A failed first launch offers retry and never invents weather',async()=>{
  const app=boot({fetch:async()=>({ok:false,status:429})});try{await tick();assert.equal(app.doc.querySelector('.temperature'),null);assert.ok(app.doc.querySelector('[data-retry]'));assert.match(app.doc.getElementById('notice').textContent,/много запросов/);}finally{app.close();}
});
test('Null readings stay unavailable and hostile place names cannot become elements',async()=>{
  const data=fixture();data.current.temperature_2m=null;data.current.surface_pressure=null;data.daily.precipitation_sum[0]=null;
  const evil={...city,name:'<img id="injected" src=x onerror=alert(1)>'};
  const app=boot({fetch:async url=>({ok:true,json:async()=>String(url).includes('/search?')?{results:[evil]}:data})});
  try{await tick();assert.match(app.doc.querySelector('.temperature').textContent,/—/);app.doc.getElementById('city-search').value='test';app.doc.getElementById('city-form').dispatchEvent(new app.w.Event('submit',{cancelable:true}));await tick();assert.equal(app.doc.getElementById('injected'),null);assert.match(app.doc.querySelector('.search-result').textContent,/<img/);}finally{app.close();}
});
test('Corrupt local preferences do not stop first launch',async()=>{
  const app=boot({saved:{city:{latitude:Infinity},recent:{broken:true},settings:null,cache:[]}});try{await tick();assert.equal(app.doc.getElementById('city-name').textContent,'Москва');assert.ok(app.doc.querySelector('.temperature'));}finally{app.close();}
});
test('Music loops at -10 dB, toggles in both controls and persists independently',async()=>{
  const app=boot();try{await tick();const {doc,w}=app;const audio=doc.getElementById('background-music');
    assert.equal(audio.volume,10**(-10/20));assert.equal(audio.loop,true);assert.equal(audio.paused,false);
    doc.getElementById('music-toggle').click();assert.equal(audio.paused,true);assert.equal(doc.getElementById('music-setting').value,'off');assert.equal(JSON.parse(w.localStorage.getItem('bluehour:music')),false);
    const select=doc.getElementById('music-setting');select.value='on';select.dispatchEvent(new w.Event('change'));await tick();assert.equal(audio.paused,false);assert.equal(doc.getElementById('music-toggle').getAttribute('aria-pressed'),'true');
    doc.querySelector('[data-view="week"]').click();assert.equal(doc.getElementById('background-music'),audio);assert.equal(audio.volume,10**(-10/20));
  }finally{app.close();}
});
test('Saved music-off preference is respected on launch',async()=>{
  const app=boot({saved:{music:false}});try{await tick();assert.equal(app.doc.getElementById('background-music').paused,true);assert.equal(app.doc.getElementById('music-setting').value,'off');}finally{app.close();}
});
