// A decibel level describes amplitude logarithmically, not a percentage slider.
export const MUSIC_GAIN = 10 ** (-10 / 20);

export function setupMusic({ audio, button, label, select, read, save, document }) {
  let enabled = read('music', true) !== false;
  let pending = false;
  let failed = false;
  let generation = 0;
  audio.volume = MUSIC_GAIN;
  audio.loop = true;

  function sync() {
    const playing = enabled && !audio.paused && !failed;
    button.setAttribute('aria-pressed', String(playing));
    button.setAttribute('aria-label', enabled ? 'Выключить музыку' : 'Включить музыку');
    button.classList.toggle('playing', playing);
    label.textContent = failed ? 'Аудио недоступно' : !enabled ? 'Музыка выключена' : pending ? 'Нажми, чтобы включить' : 'COLOR YOUR NIGHT';
    select.value = enabled ? 'on' : 'off';
  }
  async function play() {
    if (!enabled) return;
    const current = ++generation;
    failed = false;
    try {
      await audio.play();
      if (current !== generation) return;
      pending = false;
    } catch (error) {
      if (current !== generation) return;
      pending = error?.name === 'NotAllowedError';
      failed = !pending;
    }
    sync();
  }
  function setEnabled(value) {
    enabled = value;
    save('music', enabled);
    if (enabled) { void play(); }
    else { ++generation; audio.pause(); pending = false; failed = false; }
    sync();
  }
  button.addEventListener('click', () => setEnabled(pending || failed ? true : !enabled));
  select.addEventListener('change', () => setEnabled(select.value === 'on'));
  audio.addEventListener('playing', sync);
  audio.addEventListener('pause', sync);
  audio.addEventListener('error', () => { failed = true; pending = false; sync(); });
  // Browsers may block autoplay; the packaged desktop app permits it.
  const retry = () => { if (enabled && pending) void play(); };
  document.addEventListener('pointerdown', retry);
  document.addEventListener('keydown', retry);
  sync();
  if (enabled) void play();
  return { setEnabled };
}
