// Opt-in packaged-app diagnostic used by the macOS CI build only.
module.exports = async function smokeCheck(window) {
  const { app } = require('electron');
  try {
    const result = await window.webContents.executeJavaScript(`new Promise((resolve, reject) => {
      const deadline = Date.now() + 25000;
      const timer = setInterval(() => {
        const audio = document.getElementById('background-music');
        if (audio?.error) { clearInterval(timer); reject(new Error('Packaged audio cannot be decoded')); return; }
        if (audio?.readyState >= 2 && !audio.paused && audio.currentTime > 0 && document.getElementById('content').children.length) {
          clearInterval(timer);
          resolve({ platform: window.desktop?.platform, nativeTitlebar: document.body.classList.contains('platform-mac'),
            gain: audio.volume, loop: audio.loop, musicPlaying: true, mediaSeconds: audio.duration,
            version: document.getElementById('app-version').textContent });
        } else if (Date.now() > deadline) { clearInterval(timer); reject(new Error('Packaged UI/audio did not become ready')); }
      }, 200);
    })`);
    if (result.platform !== 'darwin' || !result.nativeTitlebar || !result.loop || result.version !== 'BLUE HOUR / 1.0.1' || Math.abs(result.gain - 10 ** (-10 / 20)) > 1e-9 || result.mediaSeconds < 220) {
      throw new Error('Unexpected diagnostic result: ' + JSON.stringify(result));
    }
    console.log('BLUE_HOUR_SMOKE_OK ' + JSON.stringify(result));
    app.exit(0);
  } catch (error) {
    console.error('BLUE_HOUR_SMOKE_FAILED ' + error.message);
    app.exit(1);
  }
};
