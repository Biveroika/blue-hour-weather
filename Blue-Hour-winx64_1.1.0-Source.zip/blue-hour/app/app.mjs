import { DEFAULT_CITY, condition, forecastUrl, geocodingUrl, validCity, validateForecast, localNow, nextHours, dayHours, mean, pressureTrend, numeric as n, finite, pressure, pressureUnit, windDirection, dateLabel, requestJson } from './weather.mjs';
import { escapeHtml as e, icon, chart, metric, detail, timeOnly, localDayLabel, moonIcon } from './ui.mjs';
import { setupMusic } from './music.mjs';
import { moonForDay, nightState } from './moon.mjs';
import { setupEasterEgg } from './easter-egg.mjs';

const $ = id => document.getElementById(id);
const read = (key,fallback) => { try { return JSON.parse(localStorage.getItem('bluehour:'+key)) ?? fallback; } catch { return fallback; } };
const save = (key,value) => { try { localStorage.setItem('bluehour:'+key, JSON.stringify(value)); } catch { /* Storage may be full or disabled; weather still works. */ } };
const storedCity=read('city',DEFAULT_CITY);
const storedSettings=read('settings',{});
const state = { city:validCity(storedCity)?storedCity:DEFAULT_CITY, data:null, fetchedAt:null, view:'now', day:0, chart:'temperature', pressureField:'surface_pressure', unit:storedSettings?.unit==='hpa'?'hpa':'mmhg', motion:['system','on','off'].includes(storedSettings?.motion)?storedSettings.motion:'system', cached:false, loading:false, error:null };
let recent = read('recent',[]); recent = Array.isArray(recent)?recent.filter(validCity).slice(0,6):[];
let fetchController, fetchVersion=0, searchController, searchVersion=0, searchTimer;
let lastFocus=null;
let results=[];
let musicController;
const cityTimezone = () => state.data?.timezone || state.city.timezone || 'UTC';
const cacheKey = city => `${city.latitude.toFixed(3)},${city.longitude.toFixed(3)}`;
const p = value => n(pressure(value,state.unit),1);
const pu = () => pressureUnit(state.unit);
const temp = value => finite(value) ? `${n(value)}°` : '—';
const valueUnit = (value,unit,digits=0) => finite(value)?`${n(value,digits)} ${unit}`:'—';
function applyMotion() { document.body.classList.toggle('animations-off',state.motion==='off');document.body.classList.toggle('motion-forced',state.motion==='on'); }
function persistSettings(){save('settings',{unit:state.unit,motion:state.motion});applyMotion();}
function getCache(city) {
  const cache=read('cache',{});const item=cache?.[cacheKey(city)];
  try { if (!item || !finite(item.fetchedAt) || Date.now()-item.fetchedAt>7*86400000) return null;validateForecast(item.data);return item; } catch { return null; }
}
function putCache(city,data) {
  const prior=read('cache',{});const cache=prior&&typeof prior==='object'&&!Array.isArray(prior)?prior:{};
  cache[cacheKey(city)]={data,fetchedAt:state.fetchedAt};
  save('cache',Object.fromEntries(Object.entries(cache).filter(([,v])=>v&&finite(v.fetchedAt)).sort((a,b)=>b[1].fetchedAt-a[1].fetchedAt).slice(0,6)));
}
function rememberCity(city) {
  save('city',city);recent=[city,...recent.filter(c=>cacheKey(c)!==cacheKey(city))].slice(0,6);save('recent',recent);
}
function syncClock(){
  const timezone=cityTimezone();const now=localNow(timezone);
  const night=nightState(timezone);
  document.body.classList.toggle('dark-hour',night.active);
  document.body.classList.toggle('full-moon-night',night.fullMoon);
  $('night-label').hidden=!night.active;
  $('night-label').textContent=night.fullMoon?'FULL MOON / DARK HOUR':'DARK HOUR / 23:00–01:00';
  musicController?.setTrack(night.track);
  const moonSlot=document.querySelector('[data-current-moon]');
  const moonKey=timezone+'/'+now.slice(0,10);
  if(moonSlot && moonSlot.dataset.moonKey!==moonKey){moonSlot.innerHTML=renderMoonSummary(moonForDay(now.slice(0,10),timezone));moonSlot.dataset.moonKey=moonKey;}
  $('clock-time').textContent=now.slice(11,16);
  $('clock-date').textContent=dateLabel(now,{weekday:'long',day:'numeric',month:'long'});
  $('page-date').innerHTML=`<strong>${e(dateLabel(now,{weekday:'long'}).toUpperCase())}</strong>${e(dateLabel(now,{day:'numeric',month:'long',year:'numeric'}))}`;
  $('timezone-label').textContent=timezone;
}
function syncHeader(){
  $('city-name').textContent=state.city.name;
  $('city-open').title=[state.city.name,state.city.admin1,state.city.country].filter(Boolean).join(', ');
  $('refresh').disabled=state.loading;
  $('refresh').classList.toggle('refreshing',state.loading);
  $('content').setAttribute('aria-busy',String(state.loading));
  const status=state.loading?'Обновление…':state.cached?'Сохранённая сводка':state.data?`Данные на ${timeOnly(state.data.current.time)}`:'Нет подключения';
  $('data-status').textContent=status;$('data-status').classList.toggle('cached',state.cached);
  const cachedDate=state.data?`${dateLabel(state.data.current.time)} ${timeOnly(state.data.current.time)}`:'';
  const message=state.error?(state.data?`${state.error} Показана сохранённая сводка на ${cachedDate}.`:state.error):state.cached&&state.data?`Сохранённая сводка на ${cachedDate}. Ожидаем обновления из Open-Meteo.`:'';
  $('notice').hidden=!message;$('notice').textContent=message;
  syncClock();
}
function hourlyIndex(){const h=nextHours(state.data,1);return h.length?h[0].index:null;}
function hourlyValue(field){const i=hourlyIndex();return i===null?null:state.data.hourly[field]?.[i];}
function currentDayIndex(){const ix=state.data.daily.time.indexOf(state.data.current.time.slice(0,10));return ix<0?0:ix;}
function renderMoonSummary(moon){
  const next=moon.isFull?`Пик полнолуния · ${moon.eventTime}`:moon.eventTime?`Точная фаза · ${moon.eventTime}`:moon.nextFullDate?`Полнолуние · ${dateLabel(moon.nextFullDate,{day:'numeric',month:'long'})}`:'';
  return `<div class="lunar-summary ${moon.isFull?'is-full':''}">${moonIcon(moon)}<div><small>ФАЗА ЛУНЫ</small><strong>${e(moon.name)}</strong></div><div class="lunar-illumination"><strong>${moon.illumination}%</strong><small>ОСВЕЩЕНО В ПОЛДЕНЬ</small></div><span class="lunar-next">${e(next)}<small>Местное время города</small></span></div>`;
}
function renderNow(){
  const d=state.data,c=d.current,daily=d.daily,i=currentDayIndex(),cond=condition(c.weather_code,c.is_day);
  const max=daily.temperature_2m_max?.[i],min=daily.temperature_2m_min?.[i];
  const chance=daily.precipitation_probability_max?.[i],sum=daily.precipitation_sum?.[i];
  const headline = cond.group==='rain'||cond.group==='storm'?'ЗОНТ БУДЕТ КСТАТИ.':cond.group==='snow'?'ДЕНЬ В БЕЛЫХ ТОНАХ.':finite(chance)&&chance>=55?'ВОЗМОЖНЫ ОСАДКИ.':finite(max)&&max>=28?'СЕГОДНЯ ЖАРКО.':c.is_day?'ТВОЙ ДЕНЬ. ТВОЯ ПОГОДА.':'ГОРОД ПЕРЕХОДИТ В НОЧЬ.';
  const text=`Сегодня от ${temp(min)} до ${temp(max)}. ${finite(chance)?`Максимальная вероятность осадков — ${n(chance)}%.`:'Вероятность осадков пока неизвестна.'} ${finite(sum)?`Всего за день ожидается ${n(sum,1)} мм осадков.`:''}`;
  const trend=pressureTrend(d);
  const trendText=finite(trend)?`${Math.abs(trend)<.3?'≈':trend>0?'↗':'↘'} ${n(Math.abs(pressure(trend,state.unit)),1)} ${pu()} за следующие 3 ч`:'Нет данных о динамике';
  const hours=nextHours(d,24),dataField=state.chart==='rain'?'precipitation_probability':'temperature_2m';
  const series=hours.map(h=>d.hourly[dataField]?.[h.index]);
  const slots=hours.filter((_,ix)=>ix%3===0).slice(0,8);
  return `<div class="current-grid"><section class="hero" aria-label="Текущая погода"><div class="hero-label">${state.cached?'SAVED WEATHER':'CURRENT WEATHER'} / ${c.is_day?'DAYTIME':'NIGHTTIME'}</div><div class="temperature">${e(n(c.temperature_2m))}<sup>°</sup></div><div class="condition-name">${e(cond.name)}</div><div class="hero-bottom"><span>Ощущается ${e(temp(c.apparent_temperature))}</span><span>↑ ${e(temp(max))} &nbsp; ↓ ${e(temp(min))}</span></div><div class="hero-icon">${icon(cond.icon)}</div></section><section class="briefing"><div class="section-kicker">DAILY BRIEFING / СВОДКА</div><h2>${headline}</h2><p>${e(text)}</p><div class="sun-times"><div>${e(timeOnly(daily.sunrise?.[i]))}<small>ВОСХОД</small></div><span class="sun-line" aria-hidden="true"></span><div>${e(timeOnly(daily.sunset?.[i]))}<small>ЗАКАТ</small></div></div></section></div>
  <div data-current-moon></div>
  <div class="metric-grid">${metric('Ветер',n(c.wind_speed_10m,1),'м/с',`С ${windDirection(c.wind_direction_10m)} · порывы ${valueUnit(c.wind_gusts_10m,'м/с',1)}`,'↗')}${metric('Влажность',n(c.relative_humidity_2m),'%',`Точка росы ${temp(hourlyValue('dew_point_2m'))}`,'◉')}${metric('У поверхности',p(c.surface_pressure),pu(),trendText,'◴')}${metric('Осадки за день',n(sum,1),'мм',`Вероятность ${valueUnit(chance,'%')}`,'≋')}</div>
  <div class="section-head"><h2>ПО ЧАСАМ <small>БЛИЖАЙШИЕ 24 ЧАСА</small></h2><div class="segmented" aria-label="Показатель графика"><button data-chart="temperature" class="${state.chart==='temperature'?'active':''}" aria-pressed="${state.chart==='temperature'}">Температура, °C</button><button data-chart="rain" class="${state.chart==='rain'?'active':''}" aria-pressed="${state.chart==='rain'}">Осадки, %</button></div></div>
  <div class="chart-card">${chart(series,{labels:hours.map(h=>timeOnly(h.time)),suffix:state.chart==='rain'?'%':'°C',minZero:state.chart==='rain',accessible:`${state.chart==='rain'?'Вероятность осадков':'Температура'} на следующие 24 часа. Подробные значения ниже.`})}<div class="hours-row">${slots.map(h=>{const ix=h.index;return `<div class="hour"><span class="hour-time">${e(timeOnly(h.time))}</span>${icon(condition(d.hourly.weather_code?.[ix],d.hourly.is_day?.[ix]).icon)}<strong>${e(temp(d.hourly.temperature_2m?.[ix]))}</strong><small>${e(valueUnit(d.hourly.precipitation_probability?.[ix],'%'))} осадки</small></div>`;}).join('')}</div></div>
  <div class="metric-grid">${metric('Облачность',n(c.cloud_cover),'%','Облачный покров','☁')}${metric('Видимость',finite(hourlyValue('visibility'))?n(hourlyValue('visibility')/1000,1):'—','км','Прогноз для текущего часа','◎')}${metric('УФ-индекс',n(daily.uv_index_max?.[i],1),'','Максимум за день','☼')}${metric('Световой день',finite(daily.daylight_duration?.[i])?`${Math.floor(daily.daylight_duration[i]/3600)}:${String(Math.floor(daily.daylight_duration[i]%3600/60)).padStart(2,'0')}`:'—','ч:мин','Между восходом и закатом','◒')}</div>`;
}
function renderWeek(){
  const data=state.data,d=data.daily,today=localNow(data.timezone).slice(0,10);state.day=Math.min(state.day,d.time.length-1);
  const temps=[...(d.temperature_2m_min||[]),...(d.temperature_2m_max||[])].filter(finite),lo=Math.min(...temps),hi=Math.max(...temps),range=Math.max(1,hi-lo);
  const i=state.day,day=d.time[i],hours=dayHours(data,day),average=mean(hours.map(h=>data.hourly.surface_pressure?.[h.index]));
  const cards=d.time.slice(0,7).map((date,j)=>{
    const moon=moonForDay(date,cityTimezone());
    const con=condition(d.weather_code?.[j]),low=d.temperature_2m_min?.[j],high=d.temperature_2m_max?.[j];
    const left=finite(low)?Math.max(0,(low-lo)/range*100):0,width=finite(high)&&finite(low)?Math.max(2,(high-low)/range*100):0;
    return `<button class="day-card ${j===i?'selected':''} ${moon.isFull?'full-moon':''}" data-day="${j}" aria-pressed="${j===i}" aria-label="${e(dateLabel(date))}: ${e(con.name)}, ${e(temp(low))}…${e(temp(high))}. ${e(moon.name)}, освещено ${moon.illumination}%"><span class="day-weekday">${e(localDayLabel(date,today))}</span><span class="day-date">${e(dateLabel(date,{day:'numeric',month:'short'}))}</span>${icon(con.icon)}<span class="day-condition">${e(con.name)}</span><span class="day-temps">${e(temp(high))}<small>${e(temp(low))}</small></span><span class="temp-track"><span style="left:${left}%;width:${Math.min(width,100-left)}%"></span></span><span class="day-rain">${e(valueUnit(d.precipitation_probability_max?.[j],'%'))}<br>${e(valueUnit(d.precipitation_sum?.[j],'мм',1))}</span><span class="day-moon">${moonIcon(moon)}<span>${e(moon.name)}</span></span></button>`;
  }).join('');
  return `<p class="week-intro">${state.cached?'Сохранённый прогноз':'Сегодня и следующие 6 дней'}. Выбери день, чтобы увидеть подробности.</p><div class="week-grid">${cards}</div><section class="day-detail"><div class="day-detail-top">${icon(condition(d.weather_code?.[i]).icon)}<div><h2>${e(dateLabel(day,{weekday:'long',day:'numeric',month:'long'}).toUpperCase())}</h2><p>${e(condition(d.weather_code?.[i]).name)} · ощущается от ${e(temp(d.apparent_temperature_min?.[i]))} до ${e(temp(d.apparent_temperature_max?.[i]))}</p></div></div>${renderMoonSummary(moonForDay(day,cityTimezone()))}<div class="day-detail-grid">${detail('Ветер · максимум',`${valueUnit(d.wind_speed_10m_max?.[i],'м/с',1)} / ${windDirection(d.wind_direction_10m_dominant?.[i])}`)}${detail('Порывы · максимум',valueUnit(d.wind_gusts_10m_max?.[i],'м/с',1))}${detail('Давление · среднее у поверхности',`${p(average)} ${pu()}`)}${detail('Влажность · средняя',valueUnit(mean(hours.map(h=>data.hourly.relative_humidity_2m?.[h.index])),'%',0))}${detail('Сумма осадков',valueUnit(d.precipitation_sum?.[i],'мм',1))}${detail('УФ-индекс · максимум',n(d.uv_index_max?.[i],1))}${detail('Восход',timeOnly(d.sunrise?.[i]))}${detail('Закат',timeOnly(d.sunset?.[i]))}</div></section><div class="section-head"><h2>ТЕМПЕРАТУРА В ТЕЧЕНИЕ ДНЯ</h2><span class="section-kicker">°C / МЕСТНОЕ ВРЕМЯ</span></div><div class="chart-card">${chart(hours.map(h=>data.hourly.temperature_2m?.[h.index]),{labels:hours.map(h=>timeOnly(h.time)),suffix:'°C'})}</div>`;
}
function renderPressure(){
  const d=state.data,c=d.current,field=state.pressureField,atSurface=field==='surface_pressure';
  const hours=nextHours(d,24),values=hours.map(h=>pressure(d.hourly[field]?.[h.index],state.unit)),valid=values.filter(finite);
  const trend=pressureTrend(d,field),delta=pressure(trend,state.unit);
  return `<div class="pressure-overview"><section class="pressure-hero"><div class="hero-label">${atSurface?'У ПОВЕРХНОСТИ':'НА УРОВНЕ МОРЯ'} / ${e(pu().toUpperCase())}</div><div class="pressure-number">${e(p(c[field]))}<small>${e(pu())}</small></div><div class="pressure-sub">${finite(trend)?`${Math.abs(trend)<.3?'≈ Почти без изменений':trend>0?'↗ Растёт':'↘ Снижается'} · ${e(n(Math.abs(delta),1))} ${e(pu())} за следующие 3 часа`:'Нет данных о динамике'}<br>Высота модели: ${e(valueUnit(d.elevation,'м'))}</div></section><section class="pressure-info"><div class="section-kicker">KNOW YOUR ATMOSPHERE</div><h2>ОДНА АТМОСФЕРА. ДВА ЗНАЧЕНИЯ.</h2><p>У поверхности — давление на высоте выбранной точки: ${e(p(c.surface_pressure))} ${e(pu())}. На уровне моря — приведённое значение для сравнения разных мест: ${e(p(c.pressure_msl))} ${e(pu())}. В горах разница особенно заметна.</p></section></div><div class="section-head"><h2>ДИНАМИКА / 24 ЧАСА</h2><div class="segmented" aria-label="Вид давления"><button data-pressure="surface_pressure" class="${atSurface?'active':''}" aria-pressed="${atSurface}">У поверхности</button><button data-pressure="pressure_msl" class="${!atSurface?'active':''}" aria-pressed="${!atSurface}">Уровень моря</button></div></div><div class="chart-card pressure-chart"><div class="legend"><span>${atSurface?'У поверхности':'На уровне моря'} · ${e(pu())}</span></div>${chart(values,{labels:hours.map(h=>timeOnly(h.time)),suffix:pu(),id:'pressure-fill'})}<div class="chart-foot">${e(dateLabel(hours[0]?.time||c.time))} → ${e(dateLabel(hours.at(-1)?.time||c.time))} · Все отметки — по часовому поясу ${e(d.timezone)}.</div></div><div class="pressure-stats">${metric('Минимум за 24 ч',valid.length?n(Math.min(...valid),1):'—',pu(),'В выбранном прогнозе','↓')}${metric('Среднее за 24 ч',n(mean(values),1),pu(),atSurface?'У поверхности':'Приведено к уровню моря','≈')}${metric('Максимум за 24 ч',valid.length?n(Math.max(...valid),1):'—',pu(),'В выбранном прогнозе','↑')}</div>`;
}
function render(){
  const focused=document.activeElement;
  const focusKey=focused&&$('content').contains(focused)?['day','chart','pressure'].find(key=>focused.dataset[key]!==undefined):null;
  const focusValue=focusKey?focused.dataset[focusKey]:null;
  const titles={now:['СЕЙЧАС','01 / CURRENT WEATHER','NOW'],week:['7 ДНЕЙ','02 / WEEKLY FORECAST','NEXT'],pressure:['ДАВЛЕНИЕ','03 / ATMOSPHERIC DATA','AIR']};
  $('page-title').innerHTML=titles[state.view][0]+'<span class="heading-dot">.</span>';
  $('page-eyebrow').textContent=titles[state.view][1];$('bg-word').textContent=titles[state.view][2];$('main').className='main view-'+state.view;
  document.querySelectorAll('[data-view]').forEach(b=>{const selected=b.dataset.view===state.view;b.classList.toggle('selected',selected);selected?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current');});
  if (!state.data) $('content').innerHTML=state.loading?'<div class="empty-state"><div class="empty-symbol">◒</div><h2>ЛОВИМ ПРОГНОЗ.</h2><p>Запрашиваем свежую сводку для выбранного города.</p><div class="loading-line"></div></div>':`<div class="empty-state"><div class="empty-symbol">↻</div><h2>НЕБО ПОКА НЕ НА СВЯЗИ.</h2><p>${e(state.error||'Нажми «Обновить», чтобы получить прогноз.')}</p><button class="primary-button" data-retry>ПОВТОРИТЬ ЗАПРОС ↗</button><button class="primary-button" data-choose-city>ВЫБРАТЬ ДРУГОЙ ГОРОД</button><div class="error-code">OPEN-METEO / CONNECTION</div></div>`;
  else $('content').innerHTML=state.view==='now'?renderNow():state.view==='week'?renderWeek():renderPressure();
  if(focusKey)Array.from($('content').querySelectorAll(`[data-${focusKey}]`)).find(button=>button.dataset[focusKey]===focusValue)?.focus({preventScroll:true});
  syncHeader();
}
function animateContent(){const content=$('content');content.classList.remove('enter');void content.offsetWidth;content.classList.add('enter');}
function changeView(view){
  if (!['now','week','pressure'].includes(view)||view===state.view)return;
  state.view=view;const wipe=document.querySelector('.page-wipe');wipe.classList.remove('run');void wipe.offsetWidth;wipe.classList.add('run');render();animateContent();$('main').scrollTo({top:0,behavior:'auto'});
}
async function loadWeather(city=state.city){
  if(!validCity(city))return;
  const version=++fetchVersion;fetchController?.abort();fetchController=new AbortController();
  const changed=cacheKey(city)!==cacheKey(state.city);state.city=city;state.loading=true;state.error=null;state.day=changed?0:state.day;
  if(changed||!state.data){const cached=getCache(city);state.data=cached?.data||null;state.fetchedAt=cached?.fetchedAt||null;state.cached=!!cached;}
  render();
  try {
    const data=validateForecast(await requestJson(forecastUrl(city),fetchController.signal));
    if(version!==fetchVersion)return;
    state.data=data;state.fetchedAt=Date.now();state.cached=false;state.loading=false;rememberCity(city);putCache(city,data);render();animateContent();
  }catch(error){if(version!==fetchVersion)return;state.loading=false;state.error=error.message;state.cached=!!state.data;render();}
}
function openDialog(id){
  lastFocus=document.activeElement;const dialog=$(id);if(dialog.open)return;dialog.showModal();
  if(id==='city-dialog'){$('recent-cities').innerHTML=recent.map((c,i)=>`<button data-recent="${i}">${e(c.name)}</button>`).join('')||'<span class="search-status">Здесь появятся выбранные города.</span>';$('city-search').focus();}
}
function closeDialog(id){$(id).close();lastFocus?.focus();}
async function searchCities(){
  clearTimeout(searchTimer);const query=$('city-search').value.trim();const version=++searchVersion;searchController?.abort();results=[];$('search-results').innerHTML='';
  if(query.length<2){$('search-status').textContent='Введи хотя бы два символа.';return;}
  $('search-status').textContent='Ищем город…';searchController=new AbortController();
  try {const data=await requestJson(geocodingUrl(query),searchController.signal);if(version!==searchVersion)return;
    results=Array.isArray(data.results)?data.results.filter(validCity):[];
    $('search-status').textContent=results.length?'Выбери нужный город из списка.':'Ничего не найдено. Попробуй полное название или латиницу.';
    $('search-results').innerHTML=results.map((c,i)=>`<button class="search-result" data-result="${i}"><span><strong>${e(c.name)}</strong><small>${e([c.admin1,c.country].filter(Boolean).join(' · '))}</small></span><span>↗</span></button>`).join('');
  }catch(error){if(version===searchVersion)$('search-status').textContent=error.message;}
}
function selectCity(city){closeDialog('city-dialog');$('city-search').value='';$('search-results').innerHTML='';$('search-status').textContent='Введи хотя бы два символа.';searchController?.abort();++searchVersion;loadWeather(city);}
document.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b)return;
  if(b.dataset.view)changeView(b.dataset.view);
  if(b.dataset.window)window.desktop?.control(b.dataset.window);
  if(b.dataset.close)closeDialog(b.dataset.close);
  if(b.dataset.chart){state.chart=b.dataset.chart;render();}
  if(b.dataset.pressure){state.pressureField=b.dataset.pressure;render();}
  if(b.dataset.day!==undefined){state.day=Number(b.dataset.day);render();}
  if(b.dataset.result!==undefined&&results[Number(b.dataset.result)])selectCity(results[Number(b.dataset.result)]);
  if(b.dataset.recent!==undefined&&recent[Number(b.dataset.recent)])selectCity(recent[Number(b.dataset.recent)]);
  if(b.hasAttribute('data-retry'))loadWeather();
  if(b.hasAttribute('data-choose-city'))openDialog('city-dialog');
});
$('city-open').addEventListener('click',()=>openDialog('city-dialog'));
$('settings-open').addEventListener('click',()=>openDialog('settings-dialog'));
$('refresh').addEventListener('click',()=>loadWeather());
$('city-form').addEventListener('submit',event=>{event.preventDefault();searchCities();});
$('city-search').addEventListener('input',()=>{clearTimeout(searchTimer);++searchVersion;searchController?.abort();results=[];$('search-results').innerHTML='';$('search-status').textContent=$('city-search').value.trim().length<2?'Введи хотя бы два символа.':'Ищем город…';searchTimer=setTimeout(searchCities,450);});
$('city-search').addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();$('search-results').querySelector('button')?.focus();}});
$('pressure-unit').value=state.unit;$('motion-setting').value=state.motion;
$('pressure-unit').addEventListener('change',event=>{state.unit=event.target.value;persistSettings();render();});
$('motion-setting').addEventListener('change',event=>{state.motion=event.target.value;persistSettings();});
$('source-link').addEventListener('click',()=>window.desktop?window.desktop.openSource():window.open('https://open-meteo.com/','_blank','noopener,noreferrer'));
document.querySelectorAll('dialog').forEach(dialog=>{dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeDialog(dialog.id);}});dialog.addEventListener('close',()=>lastFocus?.focus());});
document.addEventListener('keydown',event=>{
  if(event.ctrlKey||event.metaKey||event.altKey||event.repeat)return;
  if(document.querySelector('dialog[open]')||['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))return;
  const views={'1':'now','2':'week','3':'pressure'};
  if(views[event.key]){event.preventDefault();changeView(views[event.key]);}
  if(event.key==='/'){event.preventDefault();openDialog('city-dialog');}
  if(event.key===','){event.preventDefault();openDialog('settings-dialog');}
  if(event.key.toLowerCase()==='r'&&!state.loading)loadWeather();
});
if(window.desktop?.platform==='darwin')document.body.classList.add('platform-mac');
else if(window.desktop)$('window-actions').hidden=false;
if(window.desktop?.platform==='win32')$('app-version').textContent='BLUE HOUR / winx64_1.1.0';
musicController=setupMusic({track:nightState(cityTimezone()).track,audio:$('background-music'),button:$('music-toggle'),label:$('music-label'),select:$('music-setting'),read,save,document});
setupEasterEgg($('app-logo'),$('secret-message'));
setupEasterEgg($('app-version'),$('settings-secret-message'));
applyMotion();loadWeather();
// Align to minute boundaries; resync immediately on wake or city changes.
function scheduleClock(){setTimeout(()=>{syncClock();scheduleClock();},60000-Date.now()%60000+20);}
scheduleClock();
window.addEventListener('focus',syncClock);
window.addEventListener('pageshow',syncClock);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')syncClock();});
setInterval(()=>{if(!state.loading&&document.visibilityState==='visible')loadWeather();},15*60*1000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&!state.loading&&(!state.fetchedAt||Date.now()-state.fetchedAt>15*60*1000))loadWeather();});
window.addEventListener('online',()=>{if((state.cached||!state.data)&&!state.loading)loadWeather();});
