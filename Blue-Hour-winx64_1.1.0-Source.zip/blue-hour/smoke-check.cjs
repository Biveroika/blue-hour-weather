// Explicit --smoke-test diagnostic; exercised on built native applications in CI.
module.exports = async function smokeCheck(window) {
  const { app } = require('electron');
  const fs = require('node:fs/promises');
  const path = require('node:path');
  const { pathToFileURL } = require('node:url');
  const run = code => window.webContents.executeJavaScript(code);
  const output=path.resolve(process.env.BLUE_HOUR_SMOKE_DIR || 'smoke-output');
  await fs.mkdir(output,{recursive:true});
  const wait = condition => run(`new Promise((resolve,reject)=>{
    const started=performance.now();const timer=setInterval(()=>{
      if(${condition}){clearInterval(timer);resolve(true);}
      else if(performance.now()-started>30000){clearInterval(timer);reject(new Error('Timed out: '+${JSON.stringify(condition)}));}
    },100);
  })`);
  try {
    await wait(`document.getElementById('app-version')?.textContent.endsWith('1.1.0') && !document.getElementById('refresh').disabled`);
    if (!app.isPackaged || app.getVersion()!=='1.1.0') throw Error('Expected packaged Blue Hour 1.1.0');
    const { fixture } = await import(pathToFileURL(path.join(__dirname,'test/fixture.mjs')).href);
    await run(`{
      const NativeDate=Date;
      window.__smokeClock='2026-09-23T12:00:00Z';
      window.Date=class extends NativeDate{constructor(...args){super(...(args.length?args:[window.__smokeClock]));}static now(){return new NativeDate(window.__smokeClock).getTime();}};
      window.fetch=async()=>({ok:true,json:async()=>(${JSON.stringify(fixture())})});
      document.getElementById('refresh').click();
    }`);
    await wait(`!!document.querySelector('.temperature') && !document.getElementById('refresh').disabled`);
    const tracks=[];
    for (const [time,track] of [['2026-09-23T12:00:00Z','color'],['2026-09-23T20:30:00Z','voice'],['2026-09-26T20:30:00Z','shadow']]) {
      await run(`window.__smokeClock=${JSON.stringify(time)};window.dispatchEvent(new Event('focus'));`);
      await wait(`document.getElementById('background-music').dataset.track===${JSON.stringify(track)} && document.getElementById('background-music').readyState>=2 && !document.getElementById('background-music').paused && document.getElementById('background-music').currentTime>.1`);
      const result=await run(`(()=>{const a=document.getElementById('background-music');return {track:a.dataset.track,gain:a.volume,loop:a.loop,duration:a.duration,dark:document.body.classList.contains('dark-hour'),full:document.body.classList.contains('full-moon-night'),error:a.error?.message};})()`);
      if (result.error || !result.loop || result.duration<60 || Math.abs(result.gain-10**(-10/20))>1e-9 || result.dark!==(track!=='color') || result.full!==(track==='shadow')) throw Error('Audio/theme mismatch: '+JSON.stringify(result));
      tracks.push(result);
    }
    await run(`document.querySelector('[data-view="week"]').click();document.querySelector('.day-card.full-moon').click();`);
    const cards=await run(`({count:document.querySelectorAll('.day-card').length,full:document.querySelectorAll('.day-card.full-moon').length,selected:document.querySelector('.day-card.selected').classList.contains('full-moon'),green:getComputedStyle(document.querySelector('.day-card.selected')).borderTopColor})`);
    if (cards.count!==7 || cards.full!==1 || !cards.selected || cards.green!=='rgb(20, 133, 82)') throw Error('Full moon forecast mismatch: '+JSON.stringify(cards));
    await new Promise(resolve=>setTimeout(resolve,850));
    await fs.writeFile(path.join(output,'full-moon-night.png'),(await window.webContents.capturePage()).toPNG());
    await run(`window.__smokeClock='2026-09-23T12:00:00Z';window.dispatchEvent(new Event('focus'));`);
    await new Promise(resolve=>setTimeout(resolve,850));
    await fs.writeFile(path.join(output,'full-moon-day.png'),(await window.webContents.capturePage()).toPNG());
    const dayBorder=await run(`getComputedStyle(document.querySelector('.day-card.selected')).borderTopColor`);
    if(dayBorder!=='rgb(20, 133, 82)') throw Error('Full moon selection lost its green border in daytime');
    const secret=await run(`(()=>{const b=document.getElementById('app-logo');b.click();b.click();b.click();const m=document.getElementById('secret-message');return {visible:!m.hidden,text:m.textContent,color:getComputedStyle(m).color};})()`);
    if(!secret.visible || secret.text!=='maybe soon…' || secret.color!=='rgb(255, 112, 184)') throw Error('Easter egg failed');
    await new Promise(resolve=>setTimeout(resolve,450));
    await fs.writeFile(path.join(output,'easter-egg.png'),(await window.webContents.capturePage()).toPNG());
    await run(`document.getElementById('settings-open').click();document.getElementById('app-version').click();document.getElementById('app-version').click();`);
    if(await run(`!document.getElementById('settings-secret-message').hidden`)) throw Error('Settings secret appeared before third activation');
    const settingsSecret=await run(`(()=>{document.getElementById('app-version').click();const m=document.getElementById('settings-secret-message');return {visible:!m.hidden,text:m.textContent,dialog:document.getElementById('settings-dialog').open};})()`);
    if(!settingsSecret.visible || !settingsSecret.dialog || settingsSecret.text!=='саня ван лав<3') throw Error('Settings easter egg failed');
    await new Promise(resolve=>setTimeout(resolve,450));
    await fs.writeFile(path.join(output,'settings-easter-egg.png'),(await window.webContents.capturePage()).toPNG());
    await run(`document.querySelector('[data-close="settings-dialog"]').click();document.querySelector('[data-view="pressure"]').click();`);
    await wait(`!!document.querySelector('.pressure-number')`);
    const pressure=await run(`document.querySelector('.pressure-number').textContent`);
    if(!pressure.includes('747')) throw Error('Pressure screen failed: '+pressure);
    const native=await run(`({platform:window.desktop?.platform,nativeTitlebar:document.body.classList.contains('platform-mac'),windowButtons:document.getElementById('window-actions').hidden?0:document.querySelectorAll('[data-window]').length,release:document.getElementById('app-version').textContent})`);
    if(native.platform!==process.platform || native.nativeTitlebar!==(process.platform==='darwin')) throw Error('Incorrect native window platform');
    if(process.platform==='win32') {
      if(process.arch!=='x64' || native.windowButtons!==3 || native.release!=='BLUE HOUR / winx64_1.1.0' || !process.env.PORTABLE_EXECUTABLE_FILE) throw Error('Expected Windows x64 portable executable');
      const waitWindow=condition=>new Promise((resolve,reject)=>{
        const started=Date.now();const timer=setInterval(()=>{
          if(condition()){clearInterval(timer);resolve();}
          else if(Date.now()-started>5000){clearInterval(timer);reject(Error('Native window control timed out'));}
        },50);
      });
      await run(`document.querySelector('[data-window="maximize"]').click();`);
      await waitWindow(()=>window.isMaximized());
      await run(`document.querySelector('[data-window="maximize"]').click();`);
      await waitWindow(()=>!window.isMaximized());
      await run(`document.querySelector('[data-window="minimize"]').click();`);
      await waitWindow(()=>window.isMinimized());
      window.restore();
      await waitWindow(()=>!window.isMinimized());
    }
    const result={version:app.getVersion(),architecture:process.arch,packaged:app.isPackaged,portable:!!process.env.PORTABLE_EXECUTABLE_FILE,...native,tracks,cards,secret,settingsSecret,pressure};
    await fs.writeFile(path.join(output,'checks.json'),JSON.stringify(result,null,2));
    console.log('BLUE_HOUR_SMOKE_OK '+JSON.stringify(result));
    app.exit(0);
  } catch (error) {
    await fs.writeFile(path.join(output,'failure.txt'),error.stack);
    await fs.writeFile(path.join(output,'failure.png'),(await window.webContents.capturePage()).toPNG()).catch(()=>{});
    console.error('BLUE_HOUR_SMOKE_FAILED '+error.stack);
    app.exit(1);
  }
};
